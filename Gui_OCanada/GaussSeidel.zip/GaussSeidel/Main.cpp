#include <iostream>
#include <fstream>
#include <math.h>
#include <stdlib.h>
#include <string>
using namespace std;

class Gauss_Seidel
{
private:
	int n;
	double** matriz;
	double* vectorB;
	double* vectorX0;
	double* vectorX;
	//double* solvX;
	// double* mult;
public:
	Gauss_Seidel(double** B, double* c, int m)
	{
		n = m;
		matriz = new double* [n];
		for (int i = 0; i < n; i++)
			matriz[i] = new double[n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				matriz[i][j] = B[i][j];
		vectorB = new double[n];
        vectorX0 = new double[n];
		for (int i = 0; i < n; i++)
			vectorB[i] = c[i];
		//mult = new double[n];
		//solvX = new double[n];
	}
	Gauss_Seidel(int m)
	{
		n = m;
		matriz = new double* [n];
		for (int i = 0; i < n; i++)
			matriz[i] = new double[n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) // creamos la matriz identidad
				if (i == j)
					matriz[i][j] = 1;
				else
					matriz[i][j] = 0;
		vectorB = new double[n];
		for (int i = 0; i < n; i++) // vector b de unos
			vectorB[i] = 1;
        vectorX0 = new double[n];
		for (int i = 0; i < n; i++) // vector vectorX0 de unos
			vectorX0[i] = 1;
		//solvX = new double[n];
		//mult = new double[n];
	}
	friend istream& operator >>(istream& is, Gauss_Seidel S);
	friend ostream& operator <<(ostream& os, Gauss_Seidel S);
	void gaussSeidel(int, double, double);
    void imprimirMarcas();
    void imprimirVector(double*);
    double norma(double*, double*);
    void printSpaces(int, int);
};

istream& operator >>(istream& is, Gauss_Seidel S)
{
	cout << "Ingrese la matriz A :" << endl;
	for (int i = 0; i < S.n; i++)
		for (int j = 0; j < S.n; j++)
			is >> S.matriz[i][j];
	cout << "Ingrese el vector b :" << endl;
	for (int i = 0; i < S.n; i++)
		is >> S.vectorB[i];
    cout << "Ingrese el vector V :" << endl;
	for (int i = 0; i < S.n; i++)
		is >> S.vectorX0[i];
	return is;
}

ostream& operator <<(ostream& os, Gauss_Seidel S)
{
	for (int i = 0; i < S.n; i++)
	{
		os << "|\t";
		for (int j = 0; j < S.n; j++)
			os << S.matriz[i][j] << "\t";
		os << "|\t|\tx" << i + 1 << "\t|\t" << "|\t" << S.vectorB[i] << "\t|" <<  "\tv" << i + 1 << "\t|\t" << "|\t" << S.vectorX0[i] << "\t|" <<endl;
	}

	return os;
}
void Gauss_Seidel::imprimirMarcas(){
    cout << "n";
    printSpaces(1, 15);
    for (int i = 0; i < n; i++){
        cout << "X" << i;
        printSpaces(3, 30);
    }
    cout << "Error" << endl;

}
void Gauss_Seidel::imprimirVector(double* v){
    for(int i = 0;i<n;i++){
        cout << v[i];
        printSpaces(to_string(v[i]).size(), 30);
    }
}
double Gauss_Seidel::norma(double* vectorX, double* vectorX0){
    double mayor = 0;
    for (int i = 0; i < n; i++) {
        if( (vectorX[i]-vectorX0[i])>mayor ){
            mayor = vectorX[i]-vectorX0[i];
        }
    }
    double max = 0;
    for (int i = 0; i < (n-1); i++) {
        if( vectorX[i]>vectorX[i+1] ){
            max = vectorX[i];
        }else{
            max = vectorX[i+1];
        }
    }
    mayor = mayor/max;
    return mayor;
}
void Gauss_Seidel::printSpaces(int p, int k){
    if(p<k){
            for(int i = 0; i<(k-p);i++){
                cout<<" ";
            }
        }
}
void Gauss_Seidel::gaussSeidel(int iter, double alpha, double tol){
	int contador = 1;
    imprimirMarcas();
    cout << (contador-1);
    printSpaces(to_string(contador-1).size(), 15);
    imprimirVector(vectorX0);
    cout << "" << endl;
    double error = tol +1;
    vectorX = new double[n];
    while( error > tol && contador < iter){
        error = 0;
        for(int i = 1;i<n+1;i++){
            vectorX[i-1] = vectorX0[i-1];
        }
        for(int i=1;i<n+1;i++){
            double suma = 0;
            for(int j=1;j<n+1;j++){
                if(i!=j){
                    suma = suma + matriz[i-1][j-1]*vectorX[j-1];
                }
            }
            vectorX[i-1] = (vectorB[i-1]-suma)/matriz[i-1][i-1]; 
            vectorX[i-1] = alpha*(vectorX[i-1])+(1-alpha)*(vectorX0[i-1]);
        }
        error = norma(vectorX, vectorX0);
        for(int i = 1;i<n+1;i++){
            vectorX0[i-1] = vectorX[i-1];
        }
        contador = contador+1;
        cout << (contador-1);
        printSpaces(to_string(contador-1).size(), 15);
        imprimirVector(vectorX);
        cout << error << endl;
    }
    if(error<tol){
        cout << "Vector X" << endl;
        for(int i = 0; i <n; i++){
    	    cout<<"X" << (i+1) << " = " << vectorX[i]<< "\n";
        }
        cout << "es una aproximacion con una tolerancia de "<< tol << endl;
    }else{
        cout << "Fracaso en "<<iter<<" iteraciones."<< endl;
    }
        
}

int main()
{
	int n;
    int iter;
    double alpha;
    double tol;
	cout << "Ingrese n :" << endl;
	cin >> n;
    cout << "Ingrese el numero de iteraciones :" << endl;
    cin >> iter;
    cout << "Ingrese la tolerancia :" << endl;
    cin >> tol;
    cout << "Ingrese el valor de relajacion :" << endl;
    cin >> alpha;
	Gauss_Seidel S1(n);
	cin >> S1;
	cout << endl << endl;
	cout << S1;
	cout << endl << endl;
	S1.gaussSeidel(iter, alpha, tol);

	return 0;
}